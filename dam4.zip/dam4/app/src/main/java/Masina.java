public class Masina {
    private String denumire;
    private int anFabricatie;
    private String culoare;


    public Masina(String denumire, int anFabricatie, String culoare) {
        this.denumire = denumire;
        this.anFabricatie = anFabricatie;
        this.culoare = culoare;
    }

    public String getDenumire() {
        return denumire;
    }

    public void setDenumire(String denumire) {
        this.denumire = denumire;
    }

    public int getAnFabricatie() {
        return anFabricatie;
    }

    public void setAnFabricatie(int anFabricatie) {
        this.anFabricatie = anFabricatie;
    }

    public String getCuloare() {
        return culoare;
    }

    public void setCuloare(String culoare) {
        this.culoare = culoare;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Masina{");
        sb.append("denumire='").append(denumire).append('\'');
        sb.append(", anFabricatie=").append(anFabricatie);
        sb.append(", culoare='").append(culoare).append('\'');
        sb.append('}');
        return sb.toString();
    }
}

