package com.example.dam4;

import android.os.Parcel;
import android.os.Parcelable;
import android.widget.CheckBox;

public class Masina implements Parcelable{
    private String denumire;
    private int anFabricatie;
    private String culoare;

    private CheckBox disponibilOnline;


    public Masina(String denumire, int anFabricatie, String culoare, CheckBox disponibilOnline) {
        this.denumire = denumire;
        this.anFabricatie = anFabricatie;
        this.culoare = culoare;
        this.disponibilOnline = disponibilOnline;
    }

    protected Masina(Parcel in) {
        denumire = in.readString();
        anFabricatie = in.readInt();
        culoare = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(denumire);
        dest.writeInt(anFabricatie);
        dest.writeString(culoare);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<Masina> CREATOR = new Creator<Masina>() {
        @Override
        public Masina createFromParcel(Parcel in) {
            return new Masina(in);
        }

        @Override
        public Masina[] newArray(int size) {
            return new Masina[size];
        }
    };

    public String getDenumire() {
        return denumire;
    }

    public void setDenumire(String denumire) {
        this.denumire = denumire;
    }

    public int getAnFabricatie() {
        return anFabricatie;
    }

    public void setAnFabricatie(int anFabricatie) {
        this.anFabricatie = anFabricatie;
    }

    public String getCuloare() {
        return culoare;
    }

    public void setCuloare(String culoare) {
        this.culoare = culoare;
    }

    public CheckBox isDisponibilOnline() {
        return disponibilOnline;
    }

    public void setDisponibilOnline(CheckBox disponibilOnline) {
        this.disponibilOnline = disponibilOnline;
    }


    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Masina{");
        sb.append("denumire='").append(denumire).append('\'');
        sb.append(", anFabricatie=").append(anFabricatie);
        sb.append(", culoare='").append(culoare).append('\'');
        sb.append(", disponibilOnline=").append(disponibilOnline);
        sb.append('}');
        return sb.toString();
    }
}
