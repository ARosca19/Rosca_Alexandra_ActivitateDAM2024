package com.example.dam4;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.dam4.Masina;
import com.google.firebase.database.DatabaseReference;


public class AdaugareMasinaActivity extends AppCompatActivity {

    private EditText editDenumire, editCuloare, editAnFabricatie;
    private CheckBox checkBoxDisponibilOnline;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adaugare_masina);

        editDenumire = findViewById(R.id.editTextTextDenumireMasina);
        editCuloare = findViewById(R.id.editTextTextCuloare);
        editAnFabricatie = findViewById(R.id.editTextNumberDecimalAnFabricatie);
        checkBoxDisponibilOnline = findViewById(R.id.checkBoxDisponibilOnline);
        Button buttonSave = findViewById(R.id.adaugamasinabutton);

        buttonSave.setOnClickListener(view -> {
            String denumire = editDenumire.getText().toString();
            String culoare = editCuloare.getText().toString();
            int anFabricatie = Integer.parseInt(editAnFabricatie.getText().toString());
            boolean disponibilOnline = checkBoxDisponibilOnline.isChecked();

            Masina masina = new Masina(denumire, anFabricatie, culoare, checkBoxDisponibilOnline);
            if (disponibilOnline) {

//                String id = databaseReference.push().getKey();
//                databaseReference.child(id).setValue(masina);
            }
//            databaseReference = FirebaseDatabase.getInstance().getReference("masini");


            Intent resultIntent = new Intent();
            resultIntent.putExtra("masina", masina);
            setResult(RESULT_OK, resultIntent);
            finish();
        });
    }
}
