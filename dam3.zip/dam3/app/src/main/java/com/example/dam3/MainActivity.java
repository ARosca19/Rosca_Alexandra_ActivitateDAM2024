package com.example.dam3;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
    //metoda apelata la click => parametru view
    public void deschideActivitate(View view){
        Intent it=new Intent(this, MainActivity2.class);
        //string este cheia, al doilea param este informatia transmisa
        it.putExtra("text", "Acesta este un text transmis din activitatea 1");
        it.putExtra("numar1", 6);
        it.putExtra("numar2", 18);
        startActivity(it);
    }
}